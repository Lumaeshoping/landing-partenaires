import { useEffect, useRef, useState, type ReactNode } from "react";

import moussaImg from "container:///mnt/data/src/assets/9d80ec95bf48ebc5-image_20261031_141643.webp";
import fatouImg from "container:///mnt/data/src/assets/3bc87beaaa409a52-image_20261031_141647.webp";
import aidaImg from "container:///mnt/data/src/assets/43ed6fc419abcede-image_20261031_141651.webp";
import ogImg from "container:///mnt/data/src/assets/fb051ab97e228cf2-image_20261031_141707.webp";

/* ---------- Données Lumaeshoping ---------- */

const FORM_URL =
  "https://docs.google.com/forms/d/e/1FAIpQLSea6qUxc3B2_mW5IhB4LJOJgbbaOoL1hdYSG00NhlpXqlCu4g/viewform";
const WHATSAPP_DISPLAY = "78 189 01 35";
const WA_LINK =
  "https://wa.me/221781890135?text=Bonjour%2C%20je%20veux%20devenir%20partenaire%20Lumaeshoping";
const COMPANY_NAME = "Lumaeshoping";
const CONTACT_EMAIL = "Lumaeshoping@gmail.com";
const PIXEL_ID = "3243394879385329";

/* Suivi événement "Lead" (Pixel Meta) au clic sur les boutons Postuler */
function trackLead() {
  const w = window as unknown as { fbq?: (...args: unknown[]) => void };
  if (typeof w.fbq !== "undefined") {
    w.fbq("track", "Lead");
  }
}

/* ---------- Fade-in au scroll ---------- */
function Reveal({ children, className = "" }: { children: ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("is-visible");
            obs.unobserve(e.target);
          }
        });
      },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div ref={ref} className={`reveal ${className}`}>
      {children}
    </div>
  );
}

/* ---------- Petits composants ---------- */

function CtaButton({ id, light = false }: { id: string; light?: boolean }) {
  return (
    <a
      id={id}
      href={FORM_URL}
      target="_blank"
      rel="noopener"
      onClick={trackLead}
      className="flex h-14 w-full items-center justify-center rounded-full text-lg font-bold transition-transform active:scale-[0.98]"
      style={
        light
          ? { background: "#FFFFFF", color: "#0B3D24" }
          : { background: "var(--cta)", color: "var(--cta-text)" }
      }
    >
      Postuler maintenant →
    </a>
  );
}

function CheckIcon({ className = "h-4 w-4 shrink-0" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="10" fill="var(--green)" />
      <path d="M8 12.5l2.6 2.6L16 9.5" stroke="#fff" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function SectionTitle({ children, sub }: { children: ReactNode; sub?: string }) {
  return (
    <div className="mb-6 text-center">
      <h2 className="text-[26px] font-extrabold leading-tight tracking-tight">{children}</h2>
      {sub && <p className="mt-2 text-base leading-relaxed" style={{ color: "var(--muted)" }}>{sub}</p>}
    </div>
  );
}

const cardStyle: React.CSSProperties = {
  background: "var(--surface)",
  border: "1px solid var(--border)",
  borderRadius: 20,
  boxShadow: "var(--shadow)",
};

/* ---------- FAQ ---------- */

const FAQ_ITEMS: { q: string; a: string }[] = [
  {
    q: "Faut-il de l'argent pour commencer ?",
    a: "Non. 0 FCFA. Inscription gratuite. Sans capital, sans stock. Tu partages seulement.",
  },
  {
    q: "Comment je suis payé ?",
    a: "Par Wave ou Orange Money, directement sur ton numéro. Tu donnes ton numéro à l'inscription.",
  },
  {
    q: "Quand est-ce que je suis payé ?",
    a: "Chaque semaine. Toutes les ventes livrées et confirmées de la semaine sont payées le lundi suivant. Tu reçois une notification.",
  },
  {
    q: "Qui s'occupe de la livraison ?",
    a: "Nous. On gère le stock, la livraison partout au Sénégal et le paiement à la livraison. Toi tu fais seulement la promotion.",
  },
  {
    q: "Combien de temps faut-il par jour ?",
    a: "30 min à 1h suffit au début. Tu peux partager entre 2 statuts WhatsApp, 1 post Facebook et 1 vidéo TikTok. Pas besoin d'être expert.",
  },
];

function FaqItem({ q, a, open, onToggle }: { q: string; a: string; open: boolean; onToggle: () => void }) {
  return (
    <div style={cardStyle} className="overflow-hidden">
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-3 px-5 py-4 text-left"
      >
        <span className="text-base font-bold leading-snug">{q}</span>
        <svg
          className="h-5 w-5 shrink-0 transition-transform duration-300"
          style={{ color: "var(--green)", transform: open ? "rotate(45deg)" : "rotate(0deg)" }}
          viewBox="0 0 24 24"
          fill="none"
          aria-hidden="true"
        >
          <path d="M12 5v14M5 12h14" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
        </svg>
      </button>
      <div className={`faq-panel ${open ? "open" : ""}`}>
        <div>
          <p className="px-5 pb-5 text-base leading-relaxed" style={{ color: "var(--muted)" }}>
            {a}
          </p>
        </div>
      </div>
    </div>
  );
}

/* ---------- Page ---------- */

export default function App() {
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  useEffect(() => {
    document.title = "Deviens Partenaire Vendeur - Payé par Wave | Lumaeshoping Sénégal";
    const setMeta = (selector: string, attr: string, value: string) => {
      let el = document.head.querySelector<HTMLMetaElement>(selector);
      if (!el) {
        el = document.createElement("meta");
        const [k, v] = attr.split("=");
        el.setAttribute(k, v.replace(/"/g, ""));
        document.head.appendChild(el);
      }
      el.setAttribute("content", value);
    };
    setMeta('meta[name="description"]', 'name="description"',
      "Vends sans stock au Sénégal avec Lumaeshoping. Partage sur WhatsApp, Facebook, TikTok. Commission par vente livrée, payée par Wave / Orange Money. Inscription gratuite.");
    setMeta('meta[property="og:title"]', 'property="og:title"', "Deviens Partenaire Vendeur - Payé par Wave | Lumaeshoping Sénégal");
    setMeta('meta[property="og:description"]', 'property="og:description"',
      "Vends sans stock au Sénégal avec Lumaeshoping. Partage sur WhatsApp, Facebook, TikTok. Commission par vente livrée, payée par Wave / Orange Money. Inscription gratuite.");
    setMeta('meta[property="og:type"]', 'property="og:type"', "website");
    setMeta('meta[property="og:locale"]', 'property="og:locale"', "fr_SN");
    setMeta('meta[property="og:image"]', 'property="og:image"', ogImg);
    setMeta('meta[name="theme-color"]', 'name="theme-color"', "#0F9D58");

    /* Pixel Meta (ID ${PIXEL_ID}) : stub fbq local — init + PageView.
       Le chargeur externe fbevents.js ne peut pas être joint dans cet
       environnement (aucun script tiers autorisé) ; les événements sont
       mis en file d'attente sur window.fbq, prêts à être consommés. */
    const w = window as unknown as {
      fbq?: ((...args: unknown[]) => void) & { queue?: unknown[][] };
      _fbq?: unknown;
    };
    if (typeof w.fbq === "undefined") {
      const fbq = function (...args: unknown[]) {
        (fbq.queue = fbq.queue || []).push(args);
      } as ((...args: unknown[]) => void) & { queue?: unknown[][]; loaded?: boolean; version?: string };
      fbq.loaded = true;
      fbq.version = "2.0";
      fbq.queue = [];
      w.fbq = fbq;
      if (typeof w._fbq === "undefined") w._fbq = fbq;
    }
    w.fbq("init", PIXEL_ID);
    w.fbq("track", "PageView");
  }, []);

  const todayLabel = new Date().toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
  });
  const todayShort = new Date().toLocaleDateString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });

  const commissions = [
    { name: "Glacière de voiture 12V", price: "25 000 FCFA", commission: "5 000 FCFA" },
    { name: "Support téléphone auto magnétique", price: "15 000 FCFA", commission: "3 000 FCFA" },
    { name: "Coussin lombaire auto", price: "18 000 FCFA", commission: "3 500 FCFA" },
  ];

  const perks = [
    {
      title: "Code partenaire personnel",
      text: "Ton code unique pour suivre toutes tes ventes, sans erreur.",
      icon: (
        <path d="M4 8a2 2 0 012-2h12a2 2 0 012 2v8a2 2 0 01-2 2H6a2 2 0 01-2-2V8z M8 10h4M8 14h7" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
      ),
    },
    {
      title: "Lien de commande prérempli",
      text: "Ton client commande en 1 clic, ta commission est tracée automatiquement.",
      icon: (
        <path d="M10 14a5 5 0 007.07 0l2.83-2.83a5 5 0 00-7.07-7.07L11 5.93M14 10a5 5 0 00-7.07 0L4.1 12.83a5 5 0 007.07 7.07L13 18.07" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      ),
    },
    {
      title: "Kit de vente complet",
      text: "Messages WhatsApp prêts à copier, photos produits, vidéos courtes TikTok / Reels.",
      icon: (
        <path d="M12 3l1.9 4.6L18.5 9l-4.6 1.4L12 15l-1.9-4.6L5.5 9l4.6-1.4L12 3zM19 15l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8.8-2z" stroke="currentColor" strokeWidth="1.7" strokeLinejoin="round" />
      ),
    },
    {
      title: "Groupe WhatsApp d'entraide",
      text: "Entraide entre partenaires, nouveaux produits en avant-première, astuces qui marchent.",
      icon: (
        <path d="M21 11.5a8.5 8.5 0 01-12.4 7.5L3 21l2-5.4A8.5 8.5 0 1121 11.5z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
      ),
    },
    {
      title: "Bonus Défi 48h",
      text: "Fais ta première vente en 48h et reçois +1 000 FCFA de bonus, en plus de ta commission.",
      icon: (
        <path d="M13 2L4.5 13.5H11L9.5 22 19 10h-6.5L13 2z" stroke="currentColor" strokeWidth="1.8" strokeLinejoin="round" />
      ),
    },
  ];

  const personas = [
    {
      img: aidaImg,
      alt: "Aida, étudiante à Dakar",
      title: "Aida, 23 ans, étudiante à Dakar",
      badge: "Entre 2 cours",
      text: "Tu as un smartphone et 1h par jour ? Tu postes en statut WhatsApp, tes camarades commandent. Idéal pour arrondir sans rater les cours.",
    },
    {
      img: moussaImg,
      alt: "Moussa, chauffeur à Thiès",
      title: "Moussa, 31 ans, chauffeur à Thiès",
      badge: "Passion auto",
      text: "Tu connais les accessoires auto et tu es dans des groupes Facebook. Tu partages les produits que tu connais déjà. Zéro stock, Lumaeshoping livre.",
    },
    {
      img: fatouImg,
      alt: "Fatou, vendeuse TikTok",
      title: "Fatou, 28 ans, vendeuse TikTok",
      badge: "Déjà sur TikTok",
      text: "Tu fais déjà des vidéos ou tu veux te lancer. On te donne les vidéos prêtes à poster. Tu ajoutes ton lien, tu touches la commission.",
    },
  ];

  const testimonials = [
    {
      initials: "FS",
      name: "Fatou S., 26 ans",
      city: "Pikine",
      text: "Au début je pensais que c'était compliqué. J'ai posté 2 statuts WhatsApp le premier jour. Première commande le lendemain, Lumaeshoping a livré à Keur Massar. J'ai reçu 3 500 FCFA sur Wave. Ça motive !",
    },
    {
      initials: "MD",
      name: "Moussa D., 32 ans",
      city: "Thiès · Chauffeur",
      text: "Je suis dans des groupes Facebook auto. Je partage la glacière voiture. Les gens commandent, je n'ai rien à livrer. Paiement chaque lundi, toujours à l'heure sur Orange Money.",
    },
    {
      initials: "AB",
      name: "Aissatou B., 24 ans",
      city: "Dakar · Étudiante UCAD",
      text: "Je fais ça entre les cours. Le kit de messages m'aide beaucoup, je copie-colle sur WhatsApp. Groupe WhatsApp très actif, on s'entraide.",
    },
  ];

  return (
    <div
      data-safe-area-inset-root
      className="min-h-screen w-full overflow-x-clip"
      style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", background: "var(--bg)", color: "var(--text)" }}
    >
      <main className="mx-auto w-full max-w-[672px] px-5 pb-24">

        {/* ============ 1. HERO ============ */}
        <section className="pt-10 text-center">
          <span
            className="inline-block rounded-full px-4 py-1.5 text-[13px] font-bold"
            style={{ background: "var(--accent)", color: "var(--green)" }}
          >
            Recrutement ouvert au Sénégal • Places limitées
          </span>

          <h1 className="mt-5 text-[34px] font-extrabold leading-[1.12] tracking-tight sm:text-[42px]">
            Vends sans stock, sois payé par <span style={{ color: "var(--green)" }}>Wave</span>
          </h1>

          <p className="mx-auto mt-4 max-w-[520px] text-[17px] leading-relaxed" style={{ color: "var(--muted)" }}>
            Partage nos produits (accessoires auto et bien-être) sur WhatsApp, Facebook et TikTok.
            Nous livrons. Tu touches une commission sur chaque vente livrée.
          </p>

          <div className="mt-7">
            <CtaButton id="cta-hero" />
          </div>

          <p className="mt-4 flex flex-wrap items-center justify-center gap-x-2 gap-y-1 text-[14px] font-semibold">
            <span className="inline-flex items-center gap-1.5"><CheckIcon /> Inscription gratuite</span>
            <span aria-hidden="true" style={{ color: "var(--muted)" }}>·</span>
            <span className="inline-flex items-center gap-1.5"><CheckIcon /> Sans capital</span>
            <span aria-hidden="true" style={{ color: "var(--muted)" }}>·</span>
            <span className="inline-flex items-center gap-1.5"><CheckIcon /> Paiement chaque semaine</span>
          </p>

          {/* Visuel hero */}
          <img
            src={ogImg}
            alt="Vends sans stock avec Lumaeshoping : colis livré partout au Sénégal, paiement Wave"
            className="mt-8 w-full rounded-[20px] object-cover"
            style={{ border: "1px solid var(--border)", boxShadow: "var(--shadow)" }}
            loading="eager"
          />

          {/* Paiement & livraison */}
          <div className="mt-6 grid grid-cols-3 gap-3">
            {[
              { label: "Wave", sub: "Paiement mobile", path: "M3 15c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2 0 3 1.2M3 19c2.5 0 2.5-2 5-2s2.5 2 5 2 2.5-2 5-2 2 0 3 1.2M12 4a3 3 0 110 6 3 3 0 010-6z" },
              { label: "Orange Money", sub: "Paiement mobile", path: "M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1" },
              { label: "Livraison", sub: "Partout au Sénégal", path: "M3 7h11v9H3zM14 10h4l3 3v3h-7zM7.5 19a1.8 1.8 0 100-3.6 1.8 1.8 0 000 3.6zM17.5 19a1.8 1.8 0 100-3.6 1.8 1.8 0 000 3.6z" },
            ].map((b) => (
              <div key={b.label} style={cardStyle} className="flex flex-col items-center px-2 py-4">
                <svg className="h-7 w-7" viewBox="0 0 24 24" fill="none" stroke="var(--green)" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                  <path d={b.path} />
                </svg>
                <span className="mt-2 text-[14px] font-bold leading-tight">{b.label}</span>
                <span className="mt-0.5 text-[11px] leading-tight" style={{ color: "var(--muted)" }}>{b.sub}</span>
              </div>
            ))}
          </div>
        </section>

        {/* ============ 2. COMMENT ÇA MARCHE ============ */}
        <section className="mt-[72px]">
          <Reveal>
            <SectionTitle>3 étapes simples</SectionTitle>
            <div className="flex flex-col gap-4">
              {[
                {
                  n: "1",
                  title: "Tu postules",
                  text: "Remplis le formulaire en 60 secondes. Aucun papier.",
                  icon: "M8 3h8l4 4v14H8zM8 3v18M12 9h5M12 13h5M12 17h3",
                },
                {
                  n: "2",
                  title: "Tu reçois ton code partenaire",
                  text: "On t'envoie ton lien de commande prérempli + ton kit de vente.",
                  icon: "M4 7a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H6a2 2 0 01-2-2V7zM8 10h5M8 14h8M16.5 9.5h.01",
                },
                {
                  n: "3",
                  title: "Tu vends et tu es payé",
                  text: "Tu partages. Quand la commande est livrée, ta commission est envoyée par Wave ou Orange Money.",
                  icon: "M12 3v18M16.5 6.5c-.8-1-2.5-1.5-4.5-1.5-2.8 0-4.5 1.3-4.5 3.2 0 4.4 9.3 2.3 9.3 6.6 0 1.9-1.8 3.2-4.8 3.2-2 0-3.8-.6-4.7-1.7",
                },
              ].map((s) => (
                <div key={s.n} style={cardStyle} className="flex items-start gap-4 p-5">
                  <div
                    className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl"
                    style={{ background: "var(--accent)" }}
                  >
                    <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="var(--green)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                      <path d={s.icon} />
                    </svg>
                  </div>
                  <div className="min-w-0">
                    <p className="text-[12px] font-extrabold uppercase tracking-wide" style={{ color: "var(--green)" }}>
                      Étape {s.n}
                    </p>
                    <h3 className="mt-0.5 text-[17px] font-bold leading-snug">{s.title}</h3>
                    <p className="mt-1 text-[15px] leading-relaxed" style={{ color: "var(--muted)" }}>{s.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </Reveal>
        </section>

        {/* ============ 3. EXEMPLE DE COMMISSION ============ */}
        <section className="mt-[72px]">
          <Reveal>
            <SectionTitle sub="Tu touches un montant fixe par produit livré. Voici 3 exemples concrets.">
              Combien tu touches ?
            </SectionTitle>

            <div style={cardStyle} className="overflow-hidden">
              <div
                className="grid grid-cols-[1fr_auto] gap-x-3 px-5 py-3 text-[12px] font-extrabold uppercase tracking-wide sm:grid-cols-[1.4fr_1fr_1fr]"
                style={{ background: "var(--accent)", color: "var(--green)" }}
              >
                <span>Produit</span>
                <span className="hidden sm:block">Prix client</span>
                <span className="text-right sm:text-left">Ta commission</span>
              </div>
              {commissions.map((c, i) => (
                <div
                  key={c.name}
                  className="grid grid-cols-[1fr_auto] items-center gap-x-3 px-5 py-4 sm:grid-cols-[1.4fr_1fr_1fr]"
                  style={i > 0 ? { borderTop: "1px solid var(--border)" } : undefined}
                >
                  <div className="min-w-0">
                    <p className="text-[15px] font-bold leading-snug">{c.name}</p>
                    <p className="mt-0.5 text-[13px] sm:hidden" style={{ color: "var(--muted)" }}>
                      Prix client : {c.price}
                    </p>
                  </div>
                  <span className="hidden text-[15px] sm:block" style={{ color: "var(--muted)" }}>{c.price}</span>
                  <span
                    className="rounded-full px-3 py-1 text-right text-[15px] font-extrabold sm:text-left"
                    style={{ background: "var(--accent)", color: "var(--green)" }}
                  >
                    {c.commission}
                  </span>
                </div>
              ))}
            </div>

            <p className="mt-4 text-center text-[13px] italic" style={{ color: "var(--muted)" }}>
              Exemple de commission par vente livrée. Les résultats varient selon tes efforts.
            </p>

            <div className="mt-4 flex justify-center">
              <span
                className="inline-flex items-center gap-2 rounded-full px-4 py-2 text-[14px] font-bold"
                style={{ background: "var(--cta)", color: "var(--cta-text)" }}
              >
                <CheckIcon className="h-4 w-4 shrink-0" />
                Pas de stock à gérer. Pas d'argent à avancer.
              </span>
            </div>
          </Reveal>
        </section>

        {/* ============ 4. CE QUE TU REÇOIS ============ */}
        <section className="mt-[72px]">
          <Reveal>
            <SectionTitle>On te donne tout pour vendre</SectionTitle>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {perks.map((p, i) => (
                <div
                  key={p.title}
                  style={cardStyle}
                  className={`p-5 ${i === perks.length - 1 ? "sm:col-span-2" : ""}`}
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-2xl" style={{ background: "var(--accent)" }}>
                    <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" style={{ color: "var(--green)" }} aria-hidden="true">
                      {p.icon}
                    </svg>
                  </div>
                  <h3 className="mt-3 text-[16px] font-bold leading-snug">{p.title}</h3>
                  <p className="mt-1 text-[14px] leading-relaxed" style={{ color: "var(--muted)" }}>{p.text}</p>
                </div>
              ))}
            </div>
          </Reveal>
        </section>

        {/* ============ 5. PERSONAS ============ */}
        <section className="mt-[72px]">
          <Reveal>
            <SectionTitle sub="Des gens comme toi vendent déjà avec Lumaeshoping. Trouve ton profil.">
              C'est fait pour toi si…
            </SectionTitle>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              {personas.map((p) => (
                <article key={p.title} style={cardStyle} className="overflow-hidden">
                  <div className="relative">
                    <img
                      src={p.img}
                      alt={p.alt}
                      className="aspect-[4/3] w-full object-cover sm:aspect-[3/4]"
                      loading="lazy"
                    />
                    <span
                      className="absolute left-3 top-3 rounded-full px-3 py-1 text-[12px] font-extrabold"
                      style={{ background: "var(--green)", color: "#FFFFFF" }}
                    >
                      {p.badge}
                    </span>
                  </div>
                  <div className="p-5">
                    <h3 className="text-[16px] font-bold leading-snug">{p.title}</h3>
                    <p className="mt-1.5 text-[14px] leading-relaxed" style={{ color: "var(--muted)" }}>{p.text}</p>
                  </div>
                </article>
              ))}
            </div>

            <div
              className="mt-4 flex flex-col items-center justify-center gap-2 rounded-[20px] px-5 py-4 text-center sm:flex-row sm:flex-wrap sm:gap-x-6"
              style={{ background: "var(--accent)" }}
            >
              {["Pas besoin d'être influenceur", "Pas besoin de gros abonnés", "Ton téléphone suffit"].map((t) => (
                <span key={t} className="inline-flex items-center gap-1.5 text-[14px] font-bold">
                  <CheckIcon />
                  {t}
                </span>
              ))}
            </div>
          </Reveal>
        </section>

        {/* ============ 6. PREUVE SOCIALE ============ */}
        <section className="mt-[72px]">
          <Reveal>
            <SectionTitle>Ils ont commencé comme toi</SectionTitle>
            <div className="flex flex-col gap-4">
              {testimonials.map((t) => (
                <figure key={t.name} style={cardStyle} className="p-5">
                  <div className="flex items-center gap-3">
                    <span
                      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-[15px] font-extrabold"
                      style={{ background: "var(--accent)", color: "var(--green)" }}
                      aria-hidden="true"
                    >
                      {t.initials}
                    </span>
                    <div className="min-w-0">
                      <figcaption className="text-[15px] font-bold leading-tight">
                        {t.name} <span className="font-medium" style={{ color: "var(--muted)" }}>· {t.city}</span>
                      </figcaption>
                      <span className="text-[14px] tracking-[2px]" style={{ color: "#F5A623" }} aria-label="5 étoiles sur 5">
                        ★★★★★
                      </span>
                    </div>
                  </div>
                  <blockquote className="mt-3 text-[15px] leading-relaxed" style={{ color: "var(--muted)" }}>
                    « {t.text} »
                  </blockquote>
                </figure>
              ))}

              {/* Capture paiement Wave : maquette téléphone */}
              <div style={cardStyle} className="p-5">
                <p className="text-[15px] font-bold">Paiement reçu</p>
                <p className="mt-0.5 text-[13px] capitalize" style={{ color: "var(--muted)" }}>
                  {todayLabel}
                </p>

                <div className="mx-auto mt-4 w-full max-w-[320px] rounded-[32px] p-2.5" style={{ background: "#111827", boxShadow: "var(--shadow)" }}>
                  <div className="rounded-[24px] px-4 pb-5 pt-3" style={{ background: "#FFFFFF", color: "#101828" }}>
                    {/* Barre de statut du téléphone */}
                    <div className="flex items-center justify-between text-[10px] font-semibold text-neutral-500">
                      <span>09:41</span>
                      <span className="h-4 w-16 rounded-full bg-neutral-900" aria-hidden="true" />
                      <span className="flex items-center gap-1" aria-hidden="true">
                        <svg className="h-3 w-3" viewBox="0 0 24 24" fill="currentColor"><path d="M2 17h3v4H2zM7.5 13h3v8h-3zM13 9h3v12h-3zM18.5 5h3v16h-3z" /></svg>
                        <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="3" y="8" width="15" height="8" rx="2" /><path d="M21 11v2" strokeLinecap="round" /><rect x="5" y="10" width="9" height="4" rx="1" fill="currentColor" stroke="none" /></svg>
                      </span>
                    </div>

                    {/* En-tête Wave */}
                    <div className="mt-4 flex items-center gap-2.5">
                      <span className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: "#1DC8F2" }} aria-hidden="true">
                        <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" strokeWidth="2.2" strokeLinecap="round">
                          <path d="M2 15c2.7 0 2.7-2.4 5.4-2.4S10 15 12.7 15s2.7-2.4 5.4-2.4c1.6 0 2.4.8 3.9 1.6M2 19.5c2.7 0 2.7-2.4 5.4-2.4s2.6 2.4 5.3 2.4 2.7-2.4 5.4-2.4c1.6 0 2.4.8 3.9 1.6" />
                        </svg>
                      </span>
                      <div className="leading-tight">
                        <p className="text-[15px] font-extrabold">Wave</p>
                        <p className="text-[11px] text-neutral-500">Notification de paiement</p>
                      </div>
                      <span className="ml-auto rounded-full bg-emerald-50 px-2 py-0.5 text-[10px] font-bold text-emerald-600">
                        Reçu
                      </span>
                    </div>

                    {/* Montant */}
                    <div className="mt-5 text-center">
                      <p className="text-[13px] text-neutral-500">Vous avez reçu</p>
                      <p className="mt-1 text-[30px] font-extrabold leading-none tracking-tight" style={{ color: "#0F9D58" }}>
                        8 500 FCFA
                      </p>
                      <p className="mt-2 text-[14px] font-semibold">
                        de <span className="font-extrabold">Lumaeshoping</span>
                      </p>
                      <p className="mt-1 text-[12px] text-neutral-500">
                        Commission partenaire · Ventes livrées de la semaine
                      </p>
                    </div>

                    {/* Détails */}
                    <div className="mt-5 space-y-2.5 rounded-2xl bg-neutral-50 px-4 py-3 text-[12.5px]">
                      <div className="flex items-center justify-between">
                        <span className="text-neutral-500">Date</span>
                        <span className="font-semibold">{todayShort} · 08:12</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-neutral-500">Vers le numéro</span>
                        <span className="font-semibold">
                          78 <span style={{ filter: "blur(4px)" }} aria-hidden="true">189 01</span> 35
                          <span className="sr-only">(numéro partiellement masqué)</span>
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-neutral-500">Nouveau solde</span>
                        <span className="font-semibold">
                          <span style={{ filter: "blur(4px)" }} aria-hidden="true">24 300</span> FCFA
                          <span className="sr-only">(solde masqué)</span>
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-neutral-500">Frais</span>
                        <span className="font-semibold">0 FCFA</span>
                      </div>
                    </div>

                    <p className="mt-4 text-center text-[10.5px] text-neutral-400">
                      Exemple de notification de paiement de commission.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </Reveal>
        </section>

        {/* ============ 7. FAQ ============ */}
        <section className="mt-[72px]">
          <Reveal>
            <SectionTitle>Questions fréquentes</SectionTitle>
            <div className="flex flex-col gap-3">
              {FAQ_ITEMS.map((item, i) => (
                <FaqItem
                  key={item.q}
                  q={item.q}
                  a={item.a}
                  open={openFaq === i}
                  onToggle={() => setOpenFaq(openFaq === i ? null : i)}
                />
              ))}
            </div>
          </Reveal>
        </section>

        {/* ============ 8. CTA FINAL ============ */}
        <section className="mt-[72px]">
          <Reveal>
            <div className="rounded-[24px] px-6 py-9 text-center" style={{ background: "var(--green)", color: "#FFFFFF" }}>
              <h2 className="text-[26px] font-extrabold leading-tight">Prêt à démarrer sans stock ?</h2>
              <p className="mx-auto mt-2 max-w-[440px] text-[16px] leading-relaxed" style={{ color: "rgba(255,255,255,0.88)" }}>
                Postule en 60 secondes. On te répond sur WhatsApp en moins de 24h.
              </p>
              <div className="mt-6">
                <CtaButton id="cta-final" light />
              </div>
              <p className="mt-4 text-[14px] font-semibold" style={{ color: "rgba(255,255,255,0.9)" }}>
                Inscription gratuite · On t'accompagne pour ta première vente
              </p>
            </div>
          </Reveal>
        </section>

        {/* ============ 9. FOOTER ============ */}
        <footer className="mt-[72px] text-center" style={{ borderTop: "1px solid var(--border)" }}>
          <div className="pt-8">
            <p className="text-[16px] font-extrabold">{COMPANY_NAME}</p>
            <p className="mt-2 text-[14px]" style={{ color: "var(--muted)" }}>
              Contact : WhatsApp {WHATSAPP_DISPLAY} · Email {CONTACT_EMAIL}
            </p>
            <p className="mx-auto mt-4 max-w-[520px] text-[13px] leading-relaxed" style={{ color: "var(--muted)" }}>
              Site de mise en relation commerciale. Les commissions sont versées uniquement sur les ventes
              livrées. Les résultats varient selon l'implication de chaque partenaire. Aucune garantie de revenu.
            </p>
            <p className="mt-4 text-[14px]">
              <a href="#" className="font-semibold underline underline-offset-4" style={{ color: "var(--green)" }}>
                Mentions légales
              </a>
            </p>
            <p className="mt-3 pb-2 text-[13px]" style={{ color: "var(--muted)" }}>
              © 2026 {COMPANY_NAME}. Tous droits réservés.
            </p>
          </div>
        </footer>
      </main>

      {/* Bouton WhatsApp flottant */}
      <a
        href={WA_LINK}
        target="_blank"
        rel="noopener"
        aria-label="Nous contacter sur WhatsApp"
        className="wa-float fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full"
        style={{ background: "var(--wa)" }}
      >
        <svg className="h-8 w-8" viewBox="0 0 24 24" fill="#FFFFFF" aria-hidden="true">
          <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2 22l5.25-1.38a9.9 9.9 0 004.79 1.22c5.46 0 9.9-4.45 9.9-9.91C21.95 6.45 17.5 2 12.04 2zm0 18.03a8.1 8.1 0 01-4.13-1.13l-.3-.18-3.12.82.83-3.04-.19-.31a8.08 8.08 0 01-1.24-4.28c0-4.47 3.64-8.1 8.15-8.1 4.5 0 8.14 3.63 8.14 8.1 0 4.47-3.64 8.12-8.14 8.12zm4.45-6.08c-.24-.12-1.44-.71-1.66-.79-.22-.08-.39-.12-.55.12-.16.25-.63.79-.77.97-.14.18-.29.2-.53.08-.24-.12-1.03-.38-1.96-1.21-.72-.65-1.21-1.44-1.35-1.68-.14-.25-.02-.38.11-.51.11-.11.24-.29.37-.43.12-.14.16-.25.24-.41.08-.16.04-.31-.02-.43-.06-.12-.55-1.32-.75-1.84-.2-.48-.4-.42-.55-.43h-.47c-.16 0-.43.06-.65.31-.22.25-.86.85-.86 2.07 0 1.22.89 2.4 1.01 2.56.12.16 1.75 2.67 4.23 3.74.59.26 1.05.41 1.41.52.59.19 1.13.16 1.56.1.48-.07 1.44-.59 1.64-1.16.2-.57.2-1.05.14-1.16-.06-.1-.22-.16-.46-.28z" />
        </svg>
      </a>
    </div>
  );
}
